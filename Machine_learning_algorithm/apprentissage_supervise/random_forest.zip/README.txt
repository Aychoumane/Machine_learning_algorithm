Les données concernant l'exercice 2 ont été retiré afin d'alléger le fichier compressé de rendu. 
Pour éviter de retélécharger les données : 

Créer un fichier nommé "data". 

Et inclure le data set dedans, avec un nom de dossier appelé : cifar-10-batches-py

Si cela ne fonctionne pas, retirer le fichier crée, et laisser le téléchargement s'effectuer. 

Un fichier texte, est présent afin de présenter les résulats obtenus après avoir exécuter le code
du 2ème exercice.
